package net.bov.main.Commands;

import net.bov.main.NpcScheduleManager;
import net.bov.main.VenturaNPCs;
import net.bov.main.Libs.Libs;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainCommand implements Listener, CommandExecutor, TabCompleter {
    private static final Libs Libs = new Libs();

    private NpcScheduleManager mgr() {
        return VenturaNPCs.getInstance().getScheduleManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            HelpCommand(sender);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "help":
                HelpCommand(sender);
                return true;

            case "setday": {
                Player player = requirePlayer(sender);
                if (player == null) return true;
                NPC npc = resolveNpc(sender, args, 1);
                if (npc == null) return missingNpc(sender, "setday");
                mgr().setDay(npc.getId(), player.getLocation());
                player.sendMessage(Libs.format(Libs.Prefix + "&aDay location for NPC &e" + npc.getId()
                        + " &7(" + npc.getName() + ") &aset to your current position."));
                return true;
            }

            case "setnight": {
                Player player = requirePlayer(sender);
                if (player == null) return true;
                NPC npc = resolveNpc(sender, args, 1);
                if (npc == null) return missingNpc(sender, "setnight");
                mgr().setNight(npc.getId(), player.getLocation());
                player.sendMessage(Libs.format(Libs.Prefix + "&aNight location for NPC &e" + npc.getId()
                        + " &7(" + npc.getName() + ") &aset to your current position."));
                return true;
            }

            case "info": {
                NPC npc = resolveNpc(sender, args, 1);
                if (npc == null) return missingNpc(sender, "info");
                int id = npc.getId();
                sender.sendMessage(Libs.format("&6NPC &e" + id + " &7(" + npc.getName() + ")"));
                sender.sendMessage(Libs.format("&7  Day:   " + fmt(mgr().getDay(id))));
                sender.sendMessage(Libs.format("&7  Night: " + fmt(mgr().getNight(id))));
                return true;
            }

            case "clear": {
                NPC npc = resolveNpc(sender, args, 1);
                if (npc == null) return missingNpc(sender, "clear");
                mgr().clear(npc.getId());
                sender.sendMessage(Libs.format(Libs.Prefix +"&aCleared the schedule for NPC &e" + npc.getId() + "&a."));
                return true;
            }

            case "list": {
                Set<Integer> ids = mgr().managedIds();
                if (ids.isEmpty()) {
                    sender.sendMessage(Libs.format(Libs.Prefix +"&7No NPCs are scheduled yet. Use &e/vnpc setday &7and &e/vnpc setnight&7."));
                } else {
                    sender.sendMessage(Libs.format(Libs.Prefix + "&6Scheduled NPCs &7(" + ids.size() + "): &e" + ids));
                }
                return true;
            }

            case "send": {
                if (args.length < 2) {
                    sender.sendMessage(Libs.format("&cUsage: /vnpc send <day|night> [id]"));
                    return true;
                }
                NPC npc = resolveNpc(sender, args, 2);
                if (npc == null) return missingNpc(sender, "send <day|night>");
                boolean night = args[1].equalsIgnoreCase("night");
                Location target = night ? mgr().getNight(npc.getId()) : mgr().getDay(npc.getId());
                if (target == null) {
                    sender.sendMessage(Libs.format("&cNPC &e" + npc.getId() + " &chas no " + (night ? "night" : "day") + " location set."));
                    return true;
                }
                boolean ok = mgr().pathTo(npc.getId(), target);
                sender.sendMessage(ok
                        ? Libs.format(Libs.Prefix + "&aSending NPC &e" + npc.getId() + " &ato its " + (night ? "night" : "day") + " location.")
                        : Libs.format(Libs.Prefix + "&cCould not path NPC &e" + npc.getId()));
                return true;
            }

            case "reload": {
                mgr().load();
                sender.sendMessage(Libs.format(Libs.Prefix + "&aReloaded npcs.yml."));
                return true;
            }

            default:
                sender.sendMessage(Libs.format(Libs.Prefix + "&cUnknown subcommand. Try &e/vnpc help&c."));
                return true;
        }
    }

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player) {
            return (Player) sender;
        }
        sender.sendMessage(Libs.console);
        return null;
    }

    private boolean missingNpc(CommandSender sender, String usage) {
        sender.sendMessage(Libs.format(Libs.Prefix + "&cNo NPC selected. Left-click an NPC (or &e/npc select&c), "
                + "or pass an id: &e/vnpc " + usage + " <id>"));
        return true;
    }

    private NPC resolveNpc(CommandSender sender, String[] args, int idIndex) {
        if (args.length > idIndex) {
            try {
                return CitizensAPI.getNPCRegistry().getById(Integer.parseInt(args[idIndex]));
            } catch (NumberFormatException ignored) {

            }
        }
        return CitizensAPI.getDefaultNPCSelector().getSelected(sender);
    }

    private String fmt(Location l) {
        if (l == null || l.getWorld() == null) {
            return "&cunset";
        }
        return "&f" + l.getWorld().getName() + " &7"
                + Math.round(l.getX()) + ", " + Math.round(l.getY()) + ", " + Math.round(l.getZ());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            return partial(args[0], List.of("help", "setday", "setnight", "info", "clear", "list", "send", "reload"));
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("send")) {
            return partial(args[1], List.of("day", "night"));
        }
        return new ArrayList<>();
    }

    private List<String> partial(String token, List<String> options) {
        String lower = token.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(lower)) {
                out.add(o);
            }
        }
        return out;
    }

    public static void HelpCommand(CommandSender sender) {
        Libs.send(sender, Libs.CommandDivider);
        Libs.MCTitle(sender);
        Libs.send(sender, Libs.NewLine);
        Libs.FormatHelp(sender);
        Libs.Commands(sender);
        Libs.send(sender, Libs.NewLine);
        Libs.send(sender, Libs.CommandDivider);
        Libs.PluginInformation(sender);
        Libs.send(sender, Libs.CommandDivider);
    }
}