package net.bov.main;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class NpcScheduleManager {

    private static final long NIGHT_START = 13000L;

    private static final long NIGHT_END = 23000L;

    private static final long CHECK_INTERVAL = 100L;

    private final VenturaNPCs plugin;
    private final File file;
    private FileConfiguration config;

    private final Map<Integer, Location> dayLocations = new HashMap<>();
    private final Map<Integer, Location> nightLocations = new HashMap<>();

    private final Map<Integer, Boolean> lastPhase = new HashMap<>();

    private BukkitTask task;

    public NpcScheduleManager(VenturaNPCs plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "npcs.yml");
    }

    public void load() {
        this.dayLocations.clear();
        this.nightLocations.clear();
        this.lastPhase.clear();

        if (!this.plugin.getDataFolder().exists()) {
            this.plugin.getDataFolder().mkdirs();
        }
        this.config = YamlConfiguration.loadConfiguration(this.file);

        if (this.config.isConfigurationSection("npcs")) {
            Set<String> ids = this.config.getConfigurationSection("npcs").getKeys(false);
            for (String key : ids) {
                int id;
                try {
                    id = Integer.parseInt(key);
                } catch (NumberFormatException ex) {
                    this.plugin.getLogger().warning("Skipping non-numeric NPC id in npcs.yml: " + key);
                    continue;
                }
                Location day = readLoc("npcs." + key + ".day");
                Location night = readLoc("npcs." + key + ".night");
                if (day != null) {
                    this.dayLocations.put(id, day);
                }
                if (night != null) {
                    this.nightLocations.put(id, night);
                }
            }
        }
        this.plugin.getLogger().info("Loaded schedules for " + managedIds().size() + " NPC(s).");
    }

    public void save() {
        FileConfiguration out = new YamlConfiguration();
        for (int id : managedIds()) {
            Location day = this.dayLocations.get(id);
            Location night = this.nightLocations.get(id);
            if (day != null) {
                writeLoc(out, "npcs." + id + ".day", day);
            }
            if (night != null) {
                writeLoc(out, "npcs." + id + ".night", night);
            }
        }
        try {
            out.save(this.file);
        } catch (IOException ex) {
            this.plugin.getLogger().severe("Failed to save npcs.yml: " + ex.getMessage());
        }
    }

    private void writeLoc(FileConfiguration c, String path, Location l) {
        c.set(path + ".world", l.getWorld() == null ? null : l.getWorld().getName());
        c.set(path + ".x", l.getX());
        c.set(path + ".y", l.getY());
        c.set(path + ".z", l.getZ());
        c.set(path + ".yaw", (double) l.getYaw());
        c.set(path + ".pitch", (double) l.getPitch());
    }

    private Location readLoc(String path) {
        if (!this.config.contains(path + ".world")) {
            return null;
        }
        String worldName = this.config.getString(path + ".world");
        World world = worldName == null ? null : Bukkit.getWorld(worldName);
        if (world == null) {
            this.plugin.getLogger().warning("World '" + worldName + "' for " + path + " is not loaded; skipping.");
            return null;
        }
        return new Location(
                world,
                this.config.getDouble(path + ".x"),
                this.config.getDouble(path + ".y"),
                this.config.getDouble(path + ".z"),
                (float) this.config.getDouble(path + ".yaw"),
                (float) this.config.getDouble(path + ".pitch"));
    }

    public void setDay(int id, Location loc) {
        this.dayLocations.put(id, loc.clone());
        this.lastPhase.remove(id);
        save();
    }

    public void setNight(int id, Location loc) {
        this.nightLocations.put(id, loc.clone());
        this.lastPhase.remove(id);
        save();
    }

    public void clear(int id) {
        this.dayLocations.remove(id);
        this.nightLocations.remove(id);
        this.lastPhase.remove(id);
        save();
    }

    public Location getDay(int id) {
        return this.dayLocations.get(id);
    }

    public Location getNight(int id) {
        return this.nightLocations.get(id);
    }

    public boolean isManaged(int id) {
        return this.dayLocations.containsKey(id) || this.nightLocations.containsKey(id);
    }

    public Set<Integer> managedIds() {
        Set<Integer> ids = new java.util.TreeSet<>();
        ids.addAll(this.dayLocations.keySet());
        ids.addAll(this.nightLocations.keySet());
        return ids;
    }

    public void start() {
        if (this.task != null) {
            this.task.cancel();
        }

        this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tick, CHECK_INTERVAL, CHECK_INTERVAL);
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
    }

    private void tick() {
        for (int id : managedIds()) {
            Location day = this.dayLocations.get(id);
            Location night = this.nightLocations.get(id);

            Location reference = (day != null) ? day : night;
            if (reference == null || reference.getWorld() == null) {
                continue;
            }

            boolean night_ = isNight(reference.getWorld().getTime());
            Boolean previous = this.lastPhase.get(id);
            if (previous != null && previous == night_) {
                continue;
            }

            Location target = night_ ? night : day;
            if (target != null) {
                pathTo(id, target);
            }
            this.lastPhase.put(id, night_);
        }
    }

    public static boolean isNight(long time) {
        long t = time % 24000L;
        return t >= NIGHT_START && t < NIGHT_END;
    }

    public boolean pathTo(int id, Location target) {
        NPC npc = CitizensAPI.getNPCRegistry().getById(id);
        if (npc == null) {
            return false;
        }
        if (!npc.isSpawned()) {

            return false;
        }
        npc.getNavigator().setTarget(target);
        return true;
    }
}