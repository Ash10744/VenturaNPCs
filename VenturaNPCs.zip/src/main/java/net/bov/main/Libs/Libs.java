package net.bov.main.Libs;

import net.bov.main.VenturaNPCs;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.hover.content.Content;
import net.md_5.bungee.api.chat.hover.content.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class Libs {
    public static String format(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public String NewLine = "\n";
    public String Prefix = "&8[&6VNPC&8] ";
    public String cmdstarter = format("◊ ");
    public String spacer = format(" &8- ");
    public String CommandDivider = format("&8&m---------------------------------------------|>");
    public String NoPermission = format("&8[] &cYou do not have permission to use this command");
    public String console = format("&cYou must be online to run this command");
    public String Version() {return VenturaNPCs.getInstance().getDescription().getVersion();}
    public void send(CommandSender sender, String msg) {
        sender.sendMessage(String.format(msg));
    }
    public static void debugMsg(String msg) {
        Bukkit.getServer().getConsoleSender().sendMessage(msg);
    }

    public static class ChatComponent {
        TextComponent component;

        public String format(String input) {return input.length() == 0 ? "Empty" : ChatColor.translateAlternateColorCodes('&', input);}
        public ChatComponent(String message) {
            this.component = new TextComponent(this.format(message));
        }
        public TextComponent getComponent() {
            return this.component;
        }
        public void addHoverMessage(String message) {this.component.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, (new ComponentBuilder(this.format(message))).create()));}
        public void addClickEvent(String command, ClickEvent.Action action) {this.component.setClickEvent(new ClickEvent(action, command));}
    }

    public void FormatHelp(CommandSender sender) {
        ChatComponent header = new ChatComponent("&f&nAvailable Commands:&r &7[] = Required, &7<> = Optional\n\n&7&oHover / Click for Additional Information\n");
        sender.spigot().sendMessage(header.getComponent());
    }

    public void Commands(CommandSender sender) {
        helpLine(sender, "/vnpc &fsetday <id>", "Set the NPC's DAY location to where you're standing.\nUses your selected NPC, or the id you pass.", "/vnpc setday");
        helpLine(sender, "/vnpc &fsetnight <id>", "Set the NPC's NIGHT location to where you're standing.", "/vnpc setnight");
        helpLine(sender, "/vnpc &finfo <id>", "Show an NPC's stored day / night locations.", "/vnpc info");
        helpLine(sender, "/vnpc &fsend [day|night] <id>", "Make the NPC walk to a location now", "/vnpc send ");
        helpLine(sender, "/vnpc &fclear <id>", "Remove an NPC's schedule.", "/vnpc clear");
        helpLine(sender, "/vnpc &flist", "List every scheduled NPC.", "/vnpc list");
        helpLine(sender, "/vnpc &freload", "Reload npcs.yml from disk.", "/vnpc reload");
    }

    private void helpLine(CommandSender sender, String command, String description, String suggest) {
        ChatComponent msg = new ChatComponent("&6" + this.cmdstarter + "&7" + command);
        msg.addHoverMessage("&6" + command + "\n\n&7" + description);
        msg.addClickEvent(suggest, ClickEvent.Action.SUGGEST_COMMAND);
        sender.spigot().sendMessage(msg.getComponent());
    }

    public void PluginInformation(CommandSender sender) {
        TextComponent msg = new TextComponent(format("&a" + this.cmdstarter + "&b[Wiki] "));
        msg.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new Content[]{new Text(format("&6VenturaNPCs Wiki Page \n\n&7Website URL: \n&6" + this.cmdstarter + "&e&nhttps://bookofventura.net/wiki"))}));
        msg.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, "https://bookofventura.net/wiki"));
        TextComponent msg2 = new TextComponent(format("&6[VenturaNPCs] "));
        msg2.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new Content[]{new Text(format("&6VenturaNPCs Help Page \n\n&7Click Command: \n&6" + this.cmdstarter + "&e&n/vnpc"))}));
        msg2.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/vnpc"));
        TextComponent msg3 = new TextComponent(format("&e[Modules] "));
        msg3.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new Content[]{new Text(format("&6VenturaNPCs Activated Modules \n\n&7Click Command: \n&6" + this.cmdstarter + "&e&n/vr modules"))}));
        msg3.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/vnpc modules"));
        TextComponent msg4 = new TextComponent(format("&f[GitHub] "));
        msg4.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new Content[]{new Text(format("&6VenturaNPCs GitHub Page \n\n&7Website URL: \n&6" + this.cmdstarter + "&e&nhttps://github.com/Ash10744/VenturaNPCs"))}));
        msg4.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, "https://github.com/Ash10744/VenturaNPCs"));
        msg.addExtra(msg2);
        msg2.addExtra(msg3);
        msg3.addExtra(msg4);
        sender.spigot().sendMessage(msg);
    }

    public void MCTitle(CommandSender sender) {
        String Version = this.Version();
        Libs.ChatComponent msg = new Libs.ChatComponent("&6VenturaNPCs-" + Version + this.spacer + "&eHelp Menu" + this.spacer + "&6Author: &eAsh10744 ");
        msg.addHoverMessage("&7Additional Supporters: \n&6" + this.cmdstarter + "&e\n&6" + this.cmdstarter + "&e");
        sender.spigot().sendMessage(msg.getComponent());
    }
}